-- CLASE 8 - Lenguaje control


-- ejemplo valida mail

-- Bonus track
SELECT 
e.*,
case when regexp_like(e.email,'^[a-zA-Z0-9.!#$%&*+/=?^_{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$') then 'S' else 'N' end as in_email_ok
from classicmodels.employees e 


SELECT 
c.*,
case when regexp_like(c.phone,'^[0-9]+$') then 'S' else 'N' end as in_telefono_numerico
from classicmodels.customers c




-- BBDD y usuarios

use sandbox;

create user usuario1 identified with mysql_native_password BY 'C0d35p4ce.';
create database sandbox;
grant all privileges on sandbox.* to usuario1 with grant option;
grant select on classicmodels.* to usuario1;



alter user usuario1 identified with mysql_native_password BY 'NUEVO_PASS';



-- Vistas

create or replace view sandbox.orders_amount as (
select 
pedidos.*,
importes.totalAmount,
clientes.salesRepEmployeeNumber as employeeNumber

from classicmodels.orders pedidos
left join (
	select 
	o.orderNumber,
	sum(quantityOrdered*priceEach) as totalAmount
	from classicmodels.orderdetails o 
	group by 1
	order by 2 desc) importes
on pedidos.orderNumber=importes.orderNumber	

left join classicmodels.customers clientes
on pedidos.customerNumber=clientes.customerNumber 
);

show create view sandbox.orders_amount


select min(orderDate),max(orderDate)
from orders o 

-- Gestión de usuarios

GRANT SELECT
ON basedatos.tabla1 
TO usuario_conocido;

GRANT ALL
ON basedatos.tabla2
TO usuario_amigo WITH GRANT OPTION;

SHOW GRANTS FOR usuario1

create role grupoa;
grant all on base_datos.* to grupoa;
grant grupoa to usuario_tipoa;


REVOKE ALL, GRANT OPTION FROM usuario_ex_amigo;


-- consultas recursivas


WITH RECURSIVE cte_count  
AS (
      SELECT 1 as n
      UNION ALL
      SELECT n + 1 
      FROM cte_count 
      WHERE n < 10
    )
SELECT n 
FROM cte_count;

WITH RECURSIVE cte_name AS (
    initial_query  -- consulta inicial
    UNION ALL
    recursive_query -- consulta que llama a la cte recursiva
)
SELECT * FROM cte_name;


-- conversión de tipos

select 
1 as entero,
10000.2 as n_decimal,
1*1.2 as producto1,
1.23*1.2 as producto2,
1.22222*1.5555 as producto3

select 
cast(1.2 as dec(10,3)) as n_dec,
cast(1.22353 as dec(10,3)) as n_dec2,
cast(1.22222 as dec(10,3)) as n_dec3,
cast(1.5555 as dec(10,3)) as n_dec3,

cast(1.22222 as dec(10,3))*cast(1.5555 as dec(10,3)) as n_dec4,
1.22222*1.5555 as n_dec5


select 1+'1.2345' as n_dec1,
cast('1.2345' as dec(10,3))+1 as n_dec2

select concat(1,2.3,456.7)

select 
false or 2 as bool1,
'1' and true as bool2,
'asfdasf' and 2 as bool3,
1='1' as bool4,
1='1.3' as bool5,
1.3='1.3' as bool6


select 
cast(1.3456 as char(4)) as text1,
cast(1.3456 as dec(3,2)) as dec_1,
cast('abcde' as char(10)) as text2,
cast('abcde' as char(3)) as text3,
cast(true as char(3)) as text4,
cast(true as dec(2,1)) as bool1


CAST(expression AS TYPE);

-- Mejora de prestaciones

-- con usuario Root

select * From sandbox.orders_amount oa -- 80ms

create index ind_orders_customernumber on classicmodels.orders (customerNumber)

select * From sandbox.orders_amount oa -- 80ms

drop index ind_orders_customernumber on classicmodels.orders;

select * From sandbox.orders_amount oa -- 80ms

show indexes from classicmodels.orders

-- tablas de sistema

select *
from information_schema.tables

select *
from information_schema.columns

select * 
from information_schema.views

select * from mysql.general_log gl 
where user_host like '%usuario1%'

select * from mysql.user



