-- EJERCICIOS REPASO


-- Realiza un análisis sobre las evolución de las ventas, con detalle de comercial, 
-- país y ciudad del mismo, gerente de ventas y país y ciudad del cliente. 
-- Revisando el rendimiento de los gerente y buscando si hay alguna ciudad donde debemos abrir oficina

select 
base.orderDate as fecha_pedido,
year(base.orderDate) as anno_pedido,
month(base.orderDate) as mes_pedido,
DATE_FORMAT(base.orderDate,'%Y-%m') as anno_mes_pedido, -- 2004-01 
clientes.city as ciudad_cliente,
clientes.country as pais_cliente,
concat(empleados.Firstname,' ',empleados.LastName)as Nombre_empleado,
base.employeeNumber,
oficinas.city as ciudad_oficina,
oficinas.country as pais_oficina,
superior.jobTitle as cargo_superior,
count(*) as pedidos,
sum(base.totalAmount) as importe

from sandbox.orders_amount base

left join classicmodels.customers clientes 
on base.customerNumber=clientes.customerNumber 

left join classicmodels.employees empleados 
on base.employeeNumber=empleados.employeeNumber 

left join classicmodels.offices oficinas 
on empleados.officeCode=oficinas.officeCode 

left join classicmodels.employees superior 
on empleados.reportsTo=superior.employeeNumber 

group by 1,2,3,4,5,6,7,8,9,10,11


-- Analiza los productos para ver su evolución por línea de producto y revisando qué productos 
-- funcionan mejor y peor, así con cuál obtenemos más beneficio


SELECT 
base.orderDate as fx_pedido,
DATE_FORMAT(base.orderDate,'%Y-%m') as fx_anno_mes_pedido,
clientes.city as ciudad_cliente,
clientes.country as pais_cliente,
empleados.employeeNumber,
concat(empleados.Firstname,' ',empleados.LastName)as Nombre_empleado,
oficinas.city as ciudad_empleado,
oficinas.country as pais_empleado,
superior.jobTitle as cargo_superior,
productos.productcode as codigo_producto,
productos.productName as nombre_producto,
productos.productLine as linea_producto,
sum(detalle.quantityOrdered) as unidades,
sum(detalle.quantityOrdered*detalle.priceEach) as importe_venta,
sum(detalle.quantityOrdered*productos.buyprice) as importe_compra,
sum(detalle.quantityOrdered*detalle.priceEach) - sum(detalle.quantityOrdered*productos.buyprice) as margen

from classicmodels.orders base

left join classicmodels.orderdetails detalle
on base.orderNumber=detalle.orderNumber 

left join classicmodels.products productos
on detalle.productCode=productos.productCode 

left join classicmodels.customers clientes 
on base.customerNumber=clientes.customerNumber 

left join classicmodels.employees empleados 
on clientes.salesRepEmployeeNumber=empleados.employeeNumber 

left join classicmodels.offices oficinas 
on empleados.officeCode=oficinas.officeCode 


left join classicmodels.employees superior
on empleados.reportsTo=superior.employeeNumber 

group by 1,2,3,4,5,6,7,8,9,10,11,12