-- TEMA 5 


-- Subconsultas

SELECT 
    lastName, 
    firstName, 
    officeCode 
FROM employees
WHERE officeCode IN (SELECT 
            officeCode
        FROM offices
        WHERE country = 'USA');
        
       
select 
	p.*
from payments p
where amount >= (select avg(amount) from payments)
order by amount desc


select 
count(*) as pedidos,
avg(importe_pedido) as media_importe
 
from 
(
	select 
	orderNumber,
	sum(quantityOrdered*priceEach) as importe_pedido
	from orderdetails o 
	group by 1
) as tabla_derivada


-- Correlacionadas

SELECT 
    productname, 
    productline,
    buyprice
FROM products p1
WHERE
    buyprice > (SELECT 
            AVG(buyprice)
        FROM products
        WHERE productline = p1.productline)
order by 2,3 desc

select 
productLine, avg(buyPrice) as promedio
from products p 
group by 1
order by 1


-- Exist

select *
from customers c 
where exists (
	select 
	customerNumber, sum(amount) as cantidad
	from payments p 
	where YEAR(paymentDate)=2004
	and customerNumber =c.customerNumber 
	group by 1
having cantidad>100000
)

select *
from customers c 
where customerNumber in (
	select 
	customerNumber
	from payments p 
	where YEAR(paymentDate)=2004
 
	group by 1
having sum(amount)>100000
)


-- UNION

select 
firstname,
lastname
from employees
UNION
select 
contactfirstname,
contactlastname
from customers

    
   
(SELECT 
    CONCAT(trim(firstName), ' ', trim(lastName)) fullname, 
    'Employee' as contactType
FROM
    employees 
ORDER BY fullname )
UNION 
(SELECT 
    CONCAT(trim(contactFirstName), ' ', trim(contactLastName)) fullname,
    'Customer' as contactType
FROM
    customers
ORDER BY 
    fullname)
   
-- CTE o WITH

select 
tabla.customerGroup,
count(*) as ca_clientes,
sum(sales) as importe_ventas,
avg(sales) as importe_medio

from 
(
SELECT 
    customerNumber,
    ROUND(SUM(amount)) sales,
    (CASE
        WHEN SUM(amount) < 10000 THEN 'Silver'
        WHEN SUM(amount) BETWEEN 10000 AND 100000 THEN 'Gold'
        WHEN SUM(amount) > 100000 THEN 'Platinum'
    END) customerGroup
    FROM
    payments p2
        
WHERE
    YEAR(paymentDAte) = 2004
GROUP BY customerNumber 

) tabla

group by tabla.customerGroup




with rango_pagos as (
	SELECT 
    customerNumber,
    ROUND(SUM(amount)) sales,
    (CASE
        WHEN SUM(amount) < 10000 THEN 'Silver'
        WHEN SUM(amount) BETWEEN 10000 AND 100000 THEN 'Gold'
        WHEN SUM(amount) > 100000 THEN 'Platinum'
    END) customerGroup
    FROM
    payments p2
        
	WHERE
    YEAR(paymentDAte) = 2004
	GROUP BY customerNumber 

)


select 
tabla.customerGroup,
count(*) as ca_clientes,
sum(sales) as importe_ventas,
avg(sales) as importe_medio

from rango_pagos tabla

group by tabla.customerGroup

/* EJERCICIOS SUCONSULTAS */
-- Obtener los clientes sin compras


SELECT 
    clientes.customerName
FROM
    classicmodels.customers clientes
WHERE
    clientes.customerNumber NOT IN (SELECT 
            a.customerNumber
        FROM classicmodels.orders a
       );

-- Encuentra el nombre de los clientes que hayan realizado más de 10 pedidos en la tabla orders        
           
SELECT 
	clientes.customerName 
FROM classicmodels.customers clientes
WHERE customerNumber IN 
(	SELECT 
	a.customerNumber 
	FROM classicmodels.orders a
	GROUP BY a.customerNumber 
	HAVING COUNT(*) > 10
);

-- (OJO. cambia respecto a la presentación) Encuentra el nombre de los productos que hayan sido comprados en más de 25 pedidos diferentes en la tabla orderdetails

SELECT 
	productos.productName 
FROM classicmodels.products productos 
WHERE productos.productCode IN 
	(SELECT 
		a.productCode 
		FROM classicmodels.orderdetails a
		GROUP BY 1 
		HAVING COUNT(DISTINCT a.orderNumber) > 25
	);           

-- Crea una segmentación de clientes plata (hacen pagos de menos de 10K en año), oro (de 10K a 100K) y platino (más de 100K). Calcula cuántos clientes de cada tipo hay para el año 2004


-- Consulta para calcular ingresos y rango por cliente
SELECT 
    pagos.customerNumber,
    ROUND(SUM(pagos.amount)) sales,
    (CASE
        WHEN SUM(pagos.amount) < 10000 THEN 'Silver'
        WHEN SUM(pagos.amount) BETWEEN 10000 AND 100000 THEN 'Gold'
        WHEN SUM(pagos.amount) > 100000 THEN 'Platinum'
    END) customerGroup
    FROM
    classicmodels.payments pagos
        
WHERE
    YEAR(pagos.paymentDAte) = 2004
GROUP BY pagos.customerNumber;

-- Agregamos esta consulta

select 
tabla.customerGroup,
count(*) as ca_clientes,
sum(sales) as importe_ventas,
avg(sales) as importe_medio

from 
(
	SELECT 
	    pagos.customerNumber,
	    ROUND(SUM(pagos.amount)) sales,
	    (CASE
	        WHEN SUM(pagos.amount) < 10000 THEN 'Silver'
	        WHEN SUM(pagos.amount) BETWEEN 10000 AND 100000 THEN 'Gold'
	        WHEN SUM(pagos.amount) > 100000 THEN 'Platinum'
	    END) customerGroup
	    FROM
	    classicmodels.payments pagos
	        
	WHERE
	    YEAR(pagos.paymentDAte) = 2004
	GROUP BY pagos.customerNumber

) tabla

group by tabla.customerGroup

-- Joins
    
select 
clientes.*,
pedidos.ca_pedidos
from customers clientes
inner join (
	select 
		customerNumber,
		count(*) as ca_pedidos
	from orders o 
	where year(orderDate)=2004
	group by 1
	) pedidos
on clientes.customerNumber=pedidos.customerNumber
    

select 
clientes.*,
coalesce(pedidos.ca_pedidos,0) as ca_pedidos
from customers clientes
left join (
	select 
		customerNumber,
		count(*) as ca_pedidos
	from orders o 
	where year(orderDate)=2004
	group by 1
	) pedidos
on clientes.customerNumber=pedidos.customerNumber


select 
clientes.*,
coalesce(pedidos.ca_pedidos,0) as ca_pedidos
from (
	select 
		customerNumber,
		count(*) as ca_pedidos
	from orders o 
	where year(orderDate)=2004
	group by 1
	) pedidos

right join customers clientes
on clientes.customerNumber=pedidos.customerNumber



select 
	empleados.*,
	oficinas.city,
	oficinas.country 
from employees empleados
left join offices oficinas
on empleados.officeCode = oficinas.officeCode 


create table orders_preprod as select * from orders o 

insert into  orders_preprod values ('20001','2003-01-01','2003-01-05',null,'In Porcess','Test',001)

/*update orders2
set customerNumber=2000
where  year(orderDate)=2004
and customerNumber=129*/

    
select * from customers clientes
left join (
	select 
		customerNumber,
		count(*) as ca_pedidos
	from orders_preprod o 
	where year(orderDate)=2003
	group by 1
	) pedidos
on clientes.customerNumber = pedidos.customerNumber

union 
select * from customers clientes
right join (
	select 
		customerNumber,
		count(*) as ca_pedidos
	from orders2 o 
	where year(orderDate)=2003
	group by 1
	) pedidos
on clientes.customerNumber = pedidos.customerNumber


select 
local.city as equipo_local,
visitante.city as equipo_visitante
from offices local
cross join offices visitante
where local.city <>visitante.city


-- Otras consideraciones

SELECT
	customerNumber,
	customerName,
	orderNumber,
	status
FROM
	customers
INNER JOIN orders 
	USING (customerNumber);


SELECT
	clientes.customerNumber,
	clientes.customerName,
	pedidos.orderNumber,
	pedidos.status
FROM
	customers clientes, 
	orders pedidos
	
where clientes.customerNumber=pedidos.customerNumber;



select 
clientes.customerName,
clientes.customerNumber,
pedidos.anno,
pedidos.ca_pedidos
from customers clientes
inner join (
	select 
		customerNumber,
		year(orderDate) as anno,
		count(*) as ca_pedidos
	from orders2 o 
	group by 1,2
	) pedidos
on clientes.customerNumber = pedidos.customerNumber

and pedidos.anno=2004


-- Duplicados

select 
clientes.customerName,
clientes.customerNumber,
coalesce(pedidos.ca_pedidos,0) as ca_pedidos
from customers clientes
left join (
	select 
		customerNumber,
		count(*) as ca_pedidos
	from orders2 o 
	where year(orderDate)=2004
	group by 1
	) pedidos
on clientes.customerNumber = pedidos.customerNumber



select 
clientes.customerName,
clientes.customerNumber,
count(pedidos.customerNumber) as ca_pedidos
from customers clientes
left join orders pedidos  
on clientes.customerNumber = pedidos.customerNumber
and year(pedidos.orderDate)=2004
group by 1,2



select 
case when pedidos.customerNumber is not null then 'S'
	else 'N' end as in_pedido,
count(*) as clientes
from customers clientes
left join (
	select 
		customerNumber,
		count(*) as ca_pedidos
	from orders o 
	where year(orderDate)=2004
	group by 1
	) pedidos
on clientes.customerNumber = pedidos.customerNumber
group by 1


select 
case when pedidos.customerNumber is not null then 'S'
	else 'N' end as in_pedido,
count(distinct clientes.customerNumber) as clientes
from customers clientes
left join orders pedidos  
on clientes.customerNumber = pedidos.customerNumber
and year(pedidos.orderDate)=2004
group by 1


-- Minus

select 
clientes.customerNumber
from customers clientes

minus 

select 
pedidos.customerNumber
from orders pedidos
where year(pedidos.orderDate)=2004
group by 1


select 
clientes.customerNumber, clientes.customerName 
from customers clientes

left join  

(
	select 
	a.customerNumber
	from orders a
	where year(a.orderDate)=2004
	group by 1
) pedidos
on clientes.customerNumber=pedidos.customerNumber

where pedidos.customerNumber is null



select 
clientes.customerNumber

from customers clientes

intersect

select 
pedidos.customerNumber
from orders pedidos
where year(pedidos.orderDate)=2004
group by 1



select 
clientes.customerNumber, clientes.customerName 
from customers clientes

inner join  
(
	select 
	a.customerNumber
	from orders a
	where year(a.orderDate)=2004
	group by 1
) pedidos
on clientes.customerNumber=pedidos.customerNumber


-- Emula exists
select 
	c.customerNumber,
	c.customerName 
from customers c 
where exists (
	select 
	customerNumber, sum(amount) as cantidad
	from payments p 
	where YEAR(paymentDate)=2004
	and customerNumber =c.customerNumber 
	group by 1
having cantidad>100000
)


select 
	clientes.customerNumber,
	clientes.customerName,
	pagos.cantidad
from customers clientes
inner join (
	select 
	customerNumber, sum(amount) as cantidad
	from payments p 
	where YEAR(paymentDate)=2004
	group by 1
	having cantidad>100000
) pagos
on pagos.customerNumber=clientes.customerNumber 



/* EJERCICIOS JOIN */

-- Lista los pedidos con el nombre del cliente


select 
clientes.customerNumber,
clientes.customerName,
pedidos.orderNumber,
pedidos.orderDate

from classicmodels.orders pedidos
left join classicmodels.customers clientes
on pedidos.customerNumber=clientes.customerNumber;


-- Calcula cuántos empleados hay por cada oficina, por ciudad y país


select
oficinas.country,
oficinas.city, 
count(*) as ca_empleados
from classicmodels.employees empleados
left join classicmodels.offices oficinas
on empleados.officeCode=oficinas.officeCode 
group by 1,2
order by 3 desc;


-- Muestra los clientes con un rango de pedidos (0, 1 a 4, 5 a 10, más de 10)


select 
clientes.customerNumber,
clientes.customerName,
case 
	when pedidos.ca_pedidos is null 	then '1.-) Sin pedidos'
	when pedidos.ca_pedidos <=4 		then '2.-) De 1 a 4 pedidos'
	when pedidos.ca_pedidos <=10 		then '3.-) De 5 a 10 pedidos'
	when pedidos.ca_pedidos >10 		then '4.-) Mas de 10 pedidos'
	else 'REVISAR' end as in_rango_pedidos
from classicmodels.customers clientes
left join (
	select 
		customerNumber,
		count(*) as ca_pedidos
	from classicmodels.orders o 
	group by 1
	) pedidos
on clientes.customerNumber = pedidos.customerNumber
order by 3;


-- Calcula para todos los clientes, el número de pedidos, importe de los mismos y pagos para el año 2004. Analiza la relación entre pagos y pedidos

select 
clientes.customerName,
clientes.customerNumber,
coalesce(pedidos.ca_pedidos,0) as ca_pedidos,
coalesce(pedidos.importes_pedido,0) as importes_pedido,
coalesce(pagos.importes_pago,0) as importes_pagos
from classicmodels.customers clientes

left join (
	select 
		customerNumber,
		sum(importes.importe_pedido) as importes_pedido,
		count(*) as ca_pedidos
	from classicmodels.orders pedidos
	
	left join (
		select 
		o.orderNumber,
		sum(quantityOrdered*priceEach) as importe_pedido
		from classicmodels.orderdetails o 
		group by 1
		order by 2 desc) importes
	on pedidos.orderNumber=importes.orderNumber
	
	where year(pedidos.orderDate)=2004
	-- and pedidos.status<>'Cancelled'
	group by 1
	) pedidos
on pedidos.customerNumber=clientes.customerNumber


left join (
	select 
	customerNumber, sum(amount) as importes_pago
	from classicmodels.payments p 
	where YEAR(paymentDate)=2004
	group by 1
) pagos
on pagos.customerNumber=clientes.customerNumber;

/* comprobaciones de un cliente que no coincide*/
select * from classicmodels.orders o 
where customerNumber =141
and year(orderDate)=2004

select * from classicmodels.orderdetails o 
where orderLineNumber =10262


-- Compara cuántos clientes tiene asignada cada oficina y calcula el ratio de clientes por empleado


select 
oficinas.country,
oficinas.city,
count(distinct empleados.employeeNumber) as ca_empleados,
count(*) as ca_clientes,
count(*)/count(distinct empleados.employeeNumber) as ratio
from classicmodels.customers clientes

left join classicmodels.employees empleados
on clientes.salesRepEmployeeNumber=empleados.employeeNumber 

left join classicmodels.offices oficinas
on empleados.officeCode=oficinas.officeCode 

group by 1,2;


-- Para cada pedido calcula los meses desde el primer pedido del cliente 

select 
pedidos.orderNumber,
pedidos.orderDate as fx_pedido,
primer_pedido.fx_primer_pedido,
floor(datediff(pedidos.orderDate,primer_pedido.fx_primer_pedido)/30) as meses


from classicmodels.orders pedidos

left join (
	select 
	a.customerNumber,
	min(a.orderDate) as fx_primer_pedido
	from classicmodels.orders a
	group by 1
	
	) primer_pedido
on pedidos.customerNumber=primer_pedido.customerNumber

