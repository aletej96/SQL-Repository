-- Consulta sobre la tabla de empleados
select * from employees e

-- Consulta de 10 registros de tabla clientes
select a.* from customers a
limit 10;

-- Consultas de empleados con filtro y ordenación
select lastname,
firstname,
jobtitle
FROM 
employees
WHERE
jobtitle = 'Sales Rep'
ORDER BY lastName;