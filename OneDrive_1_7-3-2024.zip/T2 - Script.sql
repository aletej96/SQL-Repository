-- Primera consulta sobre la tabla de clientes
select * from customers
