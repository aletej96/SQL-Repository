/* EJERCICIOS VENTANA */

-- Obtener el producto más vendido por línea de productos


with tabla_productos as (
select 
productos.productCode,
productos.productName,
productos.productLine,
sum(detalle_pedidos.quantityOrdered) as cantidad
from classicmodels.products productos
LEFT JOIN classicmodels.orderdetails detalle_pedidos 
ON productos.productCode = detalle_pedidos.productCode
group by 1,2,3)


select 
tabla.productcode,
tabla.productname,
tabla.productline,
tabla.cantidad
from (
	select 
	tabla_productos.*,
	row_number() over(partition by tabla_productos.productLine order by cantidad desc) as orden
	from tabla_productos
) tabla
where tabla.orden=1



-- Calcular la variación del importe de los pedidos respecto al mes anterior


with ventas_mes as (
	select 
		year(orderDate) as anno,
		month(orderDate) as mes,
		sum(importes.importe_pedido) as importes_pedido,
		count(*) as ca_pedidos
	from orders pedidos
	left join (
		select 
		o.orderNumber,
		sum(quantityOrdered*priceEach) as importe_pedido
		from orderdetails o 
		group by 1
		order by 2 desc) importes
	on pedidos.orderNumber=importes.orderNumber
	group by 1,2
)
select 
base.*,
LAG(base.importes_pedido,1) over(order by base.anno, base.mes) as importes_anterior,
100*((base.importes_pedido/LAG(base.importes_pedido,1) over(order by base.anno,base.mes))-1) as porc_var_mes
from ventas_mes base

-- Averiguar quien es el empleado del mes para todos los meses de 2004



with ventas_cliente as (
	select 
		pedidos.customerNumber,
		month(pedidos.orderDate) as mes,
		sum(importes.importe_pedido) as importes_pedido,
		count(*) as ca_pedidos
	from orders pedidos
	left join (
		select 
		o.orderNumber,
		sum(quantityOrdered*priceEach) as importe_pedido
		from orderdetails o 
		group by 1
		order by 2 desc) importes
	on pedidos.orderNumber=importes.orderNumber
	where year(orderDate)=2004
	group by 1,2
)
,ventas_empleado as (
	select 
		clientes.salesRepEmployeeNumber as employeenumber,
		ventas_cliente.mes,
		sum(importes_pedido) as importes_pedido,
		sum(ca_pedidos) as ca_pedidos
	from ventas_cliente
	
	left join customers clientes
	on ventas_cliente.customernumber=clientes.customerNumber 
	
	group by 1,2)

select 
tabla.mes,
tabla.employeenumber, 
concat(empleados.firstname,' ',empleados.lastname) as employeename,
tabla.importes_pedido,
tabla.ca_pedidos
from (
	select 
	ventas_empleado.*,
	rank() over(partition by ventas_empleado.mes order by ventas_empleado.importes_pedido desc) as ranking
	from ventas_empleado
) tabla

left join employees empleados
on tabla.employeenumber=empleados.employeeNumber 
where ranking=1


-- Obtener el promedio de ventas totales para cada mes en los últimos 12 meses y su desviación estándar:

WITH ventas_mes AS (
  SELECT 
  YEAR(pedidos.orderDate) as anno,
  MONTH(pedidos.orderDate) as mes, 
  SUM(quantityOrdered*priceEach) as importe_total
  FROM classicmodels.orders pedidos
  INNER JOIN orderdetails detalle
  ON pedidos.orderNumber=detalle.orderNumber
  GROUP BY 1,2
)
SELECT
  anno,
  mes,
  importe_total,
  AVG(importe_total) OVER (rows between 11 preceding and CURRENT row) as month_avg_sales,
  STDDEV(importe_total) OVER (rows between 11 preceding and CURRENT row) as month_std_sales
FROM ventas_mes;


-- Obtener el número de pedidos y el total de ventas para cada cliente y su ranking respecto a otros clientes por número de pedidos (y si empata por importe) para 2004

with ventas_cliente as (
	select 
		pedidos.customerNumber,
		sum(importes.importe_pedido) as importes_pedido,
		count(*) as ca_pedidos
	from orders pedidos
	left join (
		select 
		o.orderNumber,
		sum(quantityOrdered*priceEach) as importe_pedido
		from orderdetails o 
		group by 1
		order by 2 desc) importes
	on pedidos.orderNumber=importes.orderNumber
	where year(orderDate)=2004
	group by 1
)
select 
ventas.customerNumber,
ventas.ca_pedidos,
ventas.importes_pedido,
rank() over(order by ca_pedidos desc, importes_pedido desc) as ranking
from ventas_cliente ventas;