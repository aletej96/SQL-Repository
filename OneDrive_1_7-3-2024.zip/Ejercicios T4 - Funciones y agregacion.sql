
/* EJERCICIOS FUNCIONES */

-- Mostrar el nombre completo de contacto de los clientes

select 
concat(trim(clientes.contactFirstName),' ',trim(clientes.contactLastName)) as Nombre
from classicmodels.customers clientes;

-- Limpiar el teléfono de los clientes españoles (paréntesis, +34, etc)

select 
clientes.phone,
replace(
	replace(
		replace(
			replace(
				clientes.phone, 
				'+34',
				''
			),
			'(',
			''),
		')',
		''),
	' ',
	'')
	as limpio
from classicmodels.customers clientes
where clientes.country in ('Spain');

-- Buscar si algún representante de empresa que se apellida Fernández


select 
* 
from classicmodels.customers clientes
where lower(clientes.contactLastName) like '%fern_ndez%'; -- En realidad al no ser CASE SENSITIVE no haría falta poner el lower

-- Calcula el precio de los productos añadiendo el IVA (21%)

select
productos.*,
productos.MSRP*1.21 as MSRP_VAT
from classicmodels.products productos;


-- Calcula los meses entre el último y el primer pedido


select 
floor(
datediff(
	(select 
	orderDate 
	from orders o 
	order by orderDate desc
	limit 1),  -- En este caso se usan subconsultas, lo veremos en la clase 5
	
	(select 
	orderDate 
	from orders o 
	order by orderDate
	limit 1)
	
	)/30) as meses;

	
-- Calcula una columna para el mes de los pedidos
	
select 
pedidos.orderNumber,
pedidos.orderDate,
DATE_FORMAT(pedidos.orderdate,'%Y-%m') as mes
from classicmodels.orders pedidos
order by 1;

-- Listar los pedidos del 2004

select 
* 
from classicmodels.orders pedidos
where extract(year from pedidos.orderdate)=2004;



/* EJERCICIOS AGREGACION */


-- Encuentra el número total de clientes en la tabla customers

SELECT COUNT(*) 
FROM customers clientes;

-- Encuentra el total de pedidos realizados por cada cliente en la tabla orders

SELECT 
	pedidos.customerNumber, 
	COUNT(*) 
FROM classicmodels.orders pedidos
GROUP BY pedidos.customerNumber
order by count(*) desc;

-- Otra opción

SELECT 
	pedidos.customerNumber, 
	COUNT(*) ca_pedidos
FROM classicmodels.orders pedidos
GROUP BY 1
order by ca_pedidos desc;

-- Encuentra el número total de productos vendidos en cada pedido en la tabla orderdetails


SELECT 
	orderNumber, 
	SUM(quantityOrdered) 
FROM orderdetails 
GROUP BY orderNumber;

-- Encuentra el importe total de dinero recaudado por cada pedido 

select 
detalle.orderNumber,
sum(detalle.quantityOrdered*priceEach) as importe_pedido
from classicmodels.orderdetails detalle 
group by 1
order by 2 desc;

-- Encuentra el número total de pedidos realizados por cada cliente en la tabla orders, pero solo para aquellos clientes que hayan realizado más de 10 pedidos.

SELECT 
pedidos.customerNumber, 
COUNT(*) 
FROM classicmodels.orders pedidos
GROUP BY 1 
HAVING COUNT(*) > 10;

-- Encuentra el número total de productos vendidos en cada producto en la tabla orderdetails, pero solo para aquellos productos que hayan vendido más de 1000 unidades

select 
detalle.productCode, 
sum(detalle.quantityOrdered) as cantidad
from classicmodels.orderdetails detalle
group by 1
having cantidad>1000
order by 2 desc;
