-- TEMA 4

--RECAP


select 
productos.*,

case
	when productos.productLine like '%Cars%' then 'Cars'
	when productos.productLine in ('Motorcycles','Trucks and Buses') then 'Other road vehicles'
	else productos.productLine 
	end as superLineaProducto
from classicmodels.products productos

where productos.productScale not in ('1:700','1:10')

order by superLineaProducto, productos.productScale


-- Funciones comparación

select coalesce(null, 0)
select coalesce(cast(null as char(20)), 0)

SELECT 
    customerName, city, COALESCE(state, 'N/A'), country
FROM
    customers;

select isnull('a')   
select isnull(null)
   
SELECT GREATEST(10, 20, 30),  
       LEAST(10, 20, 30); 


SELECT GREATEST(10, null, 30),  
       LEAST(10, null , 30);    
      
      
-- Funciones Texto

select trim(contactFirstName) from customers c 

select trim(leading '+' from phone) from customers c 

select ltrim(contactFirstName) from customers c
select rtrim(contactFirstName) from customers c

select concat('1','2','3') as string

select 
contactFirstName, 
contactLastName ,
concat(trim(contactFirstName),' ',trim(contactLastName)) 
from customers c 


select 
customerName, 
		replace(customerName, 
		'Co.',
		'Company')
	as name
			
from customers c 

select 
customerName, 
	replace(
		replace(customerName, 
		'Co.',
		'Company'),
			'Ltd.',
			'Limited')
	as name
			
from customers c 

SELECT SUBSTRING('MYSQL SUBSTRING', 6)
SELECT SUBSTRING('MYSQL SUBSTRING', -9)

select 
extension , SUBSTRING(extension,2,4) as ext
from employees e 

select 
customerName, 
SUBSTRING_INDEX(customerName, ' ',-1) as ultima,
trim(case 
	when SUBSTRING_INDEX(customerName, ' ',-1) in ('Co.','Ltd.','Inc.') then SUBSTRING_INDEX(customerName, SUBSTRING_INDEX(customerName, ' ',-1), 1) 
	else customerName end)
	as limpio 
from customers c 



select length ('Ñ'), CHAR_LENGTH('Ñ') 

select customerName , substring(customername,1,3) as izquierda from customers c 
select customerName , substring(customername,char_length(customerName)-2,3) as derecha from customers c

select customerName , left(customername,3) as izquierda from customers c 
select customerName , right(customername,3) as derecha from customers c


SELECT INSTR('MySQL INSTR', 'mysql');
SELECT INSTR('MySQL INSTR', 'INS');
SELECT INSTR('MySQL INSTR', ' ');

select SUBSTRING('MySQL INSTR', INSTR('MySQL INSTR', ' ')+1, 30) as prueba

select upper('hOla')
select lower('AhorA')

select format(12.66302,3)
select format(12.66302,2)
select format(12.66302,1)
select format(12.66302,0)

select buyPrice, format (buyPrice, 1) as precio_dec from products p 

--split PART

REPLACE(SUBSTRING(SUBSTRING_INDEX(x, delim, pos),
       LENGTH(SUBSTRING_INDEX(x, delim, pos -1)) + 1),
       delim, '');
	   
select REPLACE(SUBSTRING(SUBSTRING_INDEX('a|bb|ccc|dd', '|', 3),
       LENGTH(SUBSTRING_INDEX('a|bb|ccc|dd', '|', 3 -1)) + 1),
       '|', '');

-- Funciones matemáticas

select floor(12.83232)
select ceil(12.83232)

select round(12.83232)
select round(12.83232,1)
select round(12.83232,2)

select truncate(12.83232,0)
select truncate(12.83232,1)
select truncate(12.83232,2)

select abs(1.233232)
select abs(-1.233232)

select sign(1.233232)
select sign(-1.233232)
select sign(0)


SELECT 
    orderNumber,
    quantityOrdered as Qty,
    case when MOD(quantityOrdered,2) = 0 then 'Par'
    else 'Impar' end as in_par_impar
FROM
    orderdetails

    
    
select
grupo, count(*)
from 
(
SELECT 
    orderNumber,
    mod(orderNumber,4) as grupo
FROM
    orderdetails
) a    
group by 1   
    
    
select 10+rand()*10
select round(rand()*10000000000) as aletorio
    
select * from customers c 
order by rand()

-- Funciones de fecha

select now(), curdate(), current_date, current_date(), date(now())

select date_add(CURRENT_DATE,interval 2 day)
select CURRENT_DATE()+2 

select date_add(CURRENT_TIME,interval 2 minute)


select date_sub(CURRENT_DATE,interval 2 day)

select date_sub(CURRENT_TIME,interval 2 minute)
select date_sub(CURRENT_TIME,interval 1 year)



select 
orderNumber,
orderDate, 
shippedDate,
DATEDIFF(shippedDate,orderDate) as dias
from orders

select TIMEDIFF(now(),date_sub(now(), interval 23 hour )) 

select 
orderNumber,
orderDate, 
shippedDate,
TIMEDIFF(shippedDate,orderDate) as dias
from orders

select last_day(CURRENT_DATE()) 

select extract(SECOND_MICROSECOND from now())
select extract(SECOND from now())

select extract(year from current_date),extract(month from current_date),extract(day from current_date)

select year(current_date),month(current_date),day(current_date)

select DAYNAME(now()), DAYOFWEEK(now()) , DAYOFMONTH(CURRENT_DATE())

select week('1977-01-01',3), yearweek('1977-01-01',3)

select str_to_Date('2001-11-27','%Y-%m-%d')

select str_to_Date('2001-11-27 23:34:23','%Y-%m-%d %H:%i:%S')

select date_format(CURRENT_TIME() ,'%Y-%m-%d %H:%i:%S')
select date_format(CURRENT_TIME() ,'%y-%m-%d %H:%i:%S')

select orderNumber, orderDate, DATE_FORMAT(orderDate,'%Y-%m') as mes From orders

-- Ejercicios funciones

select concat(trim(contactFirstName),' ',trim(contactLastName)) as Nombre
from customers c 

select DISTINCT 
phone,
replace(
	replace(
		replace(
			replace(
				phone, 
				'+34',
				''
			),
			'(',
			''),
		')',
		''),
	' ',
	'')
	as limpio
from customers c 
where country in ('Spain')


select * from customers c 
where lower(contactLastName) like '%fern_ndez%'

select 
floor(
datediff(
	(select 
	orderDate 
	from orders o 
	order by orderDate desc
	limit 1),
	
	(select 
	orderDate 
	from orders o 
	order by orderDate
	limit 1)
	
	)/30) as meses
	
select distinct
orderDate,
DATE_FORMAT(orderdate,'%Y-%m') as mes
from orders 
order by 1

select * from 
orders 
where extract(year from orderdate)=2004


-- Group by

select status from orders o 
group by status 

select status from orders o 
group by 1

select distinct status from orders o

select 
	city, 
	country 
from customers c 
group by 1,2
order by 2,1



select 
	city, 
	country,
	count(*) as ca_clientes
from customers c 
group by 1,2
having ca_clientes>1
order by 3 desc

select max(amount) as mayor_pago 
from payments 

select 
extract(year from paymentDate) as anno,
max(amount) as mayor_pago 
from payments 
group by 1


select 
extract(year from paymentDate) as anno,
extract(month from paymentDate) as mes,
max(amount) as mayor_pago 
from payments 
group by 1,2
having mayor_pago>60000

select 
customerNumber,
sum(amount) as total
from payments p 
group by 1
order by 2 desc


select 
customerNumber,
sum(amount) as total
from payments p 
where year(paymentDate)=2005
group by 1
order by 2 desc
limit 10


select 
customerNumber ,
AVG(amount) as media_pedidos,
count(*) as pedidos
from payments p 
group by 1
order by 3 desc

select count(*),
avg(amount),
std(amount)
from payments p 

select 
customerNumber,
count(*) as pagos,
sum(amount) as importe_total,
avg(amount) as importe_medio,
std(amount) as desviacion_importe
from payments p 
group by 1
order by 3 desc


select 
extract(year from paymentDate) as anno,
extract(month from paymentDate) as mes,
count(*) as pagos,
sum(amount) as importe_pagos,
avg(amount) as media_importe
from payments 
group by anno,mes with rollup 

-- comprtamiento MySQL 
select 
extract(year from paymentDate) as anno,
extract(month from paymentDate) as mes,
paymentDate,
count(*) as pagos,
sum(amount) as importe_pagos,
avg(amount) as media_importe
from payments 
group by anno,mes
order by anno,mes


-- Ejercicios agregacion
SELECT COUNT(*) 
FROM customers;

SELECT 
	customerNumber, 
	COUNT(*) 
FROM orders 
GROUP BY customerNumber 
order by count(*) desc;


SELECT 
	orderNumber, 
	SUM(quantityOrdered) 
FROM orderdetails 
GROUP BY orderNumber;

select 
orderNumber,
sum(quantityOrdered*priceEach) as importe_pedido
from orderdetails o 
group by 1
order by 2 desc

SELECT 
	customerNumber, 
	COUNT(*) 
FROM orders o 
GROUP BY 1 
HAVING COUNT(*) > 10;

select 
productCode, 
sum(quantityOrdered) as cantidad
from orderdetails o 
group by 1
having cantidad>1000
order by 2 desc
