
-- FUNCIONES VENTANA

-- ejemplo 
with ventas_mes as (
	select 
		year(orderDate) as anno,
		month(orderDate) as mes,
		sum(importes.importe_pedido) as importes_pedido,
		count(*) as ca_pedidos
	from orders pedidos
	left join (
		select 
		o.orderNumber,
		sum(quantityOrdered*priceEach) as importe_pedido
		from orderdetails o 
		group by 1
		order by 2 desc) importes
	on pedidos.orderNumber=importes.orderNumber
	group by 1,2
)


select 
base.*,
sum(importes_pedido) over(partition by anno order by mes) as importes_acumulados,
sum(ca_pedidos) over(partition by anno order by mes) as ca_pedidos_acumulados
from ventas_mes base

/* select * from ventas_mes*/


-- Sintaxis

window_function_name([expression]) OVER ( 
   [partition_defintion]
   [order_definition]
   [frame_definition]
)


with ventas_mes as (
	select 
		year(orderDate) as anno,
		month(orderDate) as mes,
		sum(importes.importe_pedido) as importes_pedido,
		count(*) as ca_pedidos
	from orders pedidos
	left join (
		select 
		o.orderNumber,
		sum(quantityOrdered*priceEach) as importe_pedido
		from orderdetails o 
		group by 1
		order by 2 desc) importes
	on pedidos.orderNumber=importes.orderNumber
	group by 1,2
)


select 
base.*,
avg(importes_pedido) over(	partition by anno 
							order by mes
							rows between 2 preceding and current row
							) as importe_trimestral_medio
from ventas_mes base


-- de agregacion

with ventas_mes as (
	select 
		year(orderDate) as anno,
		month(orderDate) as mes,
		sum(importes.importe_pedido) as importes_pedido,
		count(*) as ca_pedidos
	from orders pedidos
	left join (
		select 
		o.orderNumber,
		sum(quantityOrdered*priceEach) as importe_pedido
		from orderdetails o 
		group by 1
		order by 2 desc) importes
	on pedidos.orderNumber=importes.orderNumber
	group by 1,2
)


select 
base.*,
sum(importes_pedido) over(	partition by anno 
							order by mes
							rows between 2 preceding and current row
							) as importe_trimestral_acumulado,
avg(importes_pedido) over(	partition by anno 
							order by mes
							rows between 2 preceding and current row
							) as importe_trimestral_medio,							
max(importes_pedido) over(	partition by anno 
							order by mes
							rows between 2 preceding and current row
							) as importe_trimestral_max,
min(importes_pedido) over(	partition by anno 
							order by mes
							rows between 2 preceding and current row
							) as importe_trimestral_min
from ventas_mes base


-- valor enesimo

with ventas_mes as (
	select 
		year(orderDate) as anno,
		month(orderDate) as mes,
		sum(importes.importe_pedido) as importes_pedido,
		count(*) as ca_pedidos
	from orders pedidos
	left join (
		select 
		o.orderNumber,
		sum(quantityOrdered*priceEach) as importe_pedido
		from orderdetails o 
		group by 1
		order by 2 desc) importes
	on pedidos.orderNumber=importes.orderNumber
	group by 1,2
)
select 
base.*,
LAG(base.importes_pedido,1) over(order by base.anno,base.mes) as anterior,
LEAD(base.importes_pedido,1) over(order by base.anno,base.mes) as posterior,
LAST_VALUE(base.mes) over(partition by base.anno order by base.importes_pedido 
	rows between unbounded preceding and unbounded following) as ultimo,
FIRST_VALUE(base.mes) over(partition by base.anno order by base.importes_pedido 
	rows between unbounded preceding and unbounded following) as primero

from ventas_mes base
order by 1,2

-- ordenacion

with ventas_cliente as (
	select 
		pedidos.customerNumber,
		sum(importes.importe_pedido) as importes_pedido,
		count(*) as ca_pedidos
	from orders pedidos
	left join (
		select 
		o.orderNumber,
		sum(quantityOrdered*priceEach) as importe_pedido
		from orderdetails o 
		group by 1
		order by 2 desc) importes
	on pedidos.orderNumber=importes.orderNumber
	where year(orderDate)=2004
	group by 1
)

select 
base.*,
round(base.importes_pedido/10000) as importe_redondeado,
RANK() over(order by round(base.importes_pedido/10000)) as fv_rank,
DENSE_RANK() over(order by round(base.importes_pedido/10000)) as fv_dense_rank,
ROW_NUMBER () over(order by round(base.importes_pedido/10000)) as fv_row_number
from ventas_cliente base


-- agrupacion

with ventas_cliente as (
	select 
		pedidos.customerNumber,
		sum(importes.importe_pedido) as importes_pedido,
		count(*) as ca_pedidos
	from orders pedidos
	left join (
		select 
		o.orderNumber,
		sum(quantityOrdered*priceEach) as importe_pedido
		from orderdetails o 
		group by 1
		order by 2 desc) importes
	on pedidos.orderNumber=importes.orderNumber
	where year(orderDate)=2004
	group by 1
)

select 
base.*,
PERCENT_RANK() over(order by base.importes_pedido) as percentil_decimal,
round(100*PERCENT_RANK() over(order by base.importes_pedido)) as percentil,
NTILE(10) over(order by base.importes_pedido) as decil,
ceil(10*PERCENT_RANK() over(order by base.importes_pedido)) as decil_bis,
CUME_DIST() over(order by base.importes_pedido) as distribucion
from ventas_cliente base


--- EXpresiones regulares

select regexp_like('fooword', 'fo');
select 'fooword' like '%fo%'


select regexp_like('fooword', '^fo'); -- 1
select regexp_like('fooword', '^oo'); -- 0

select 'fooword' like 'fo%'
select 'fooword' like 'oo%'

select regexp_like('fooword', 'rd$'); -- 1
select regexp_like('fooword', 'oo$'); -- 0

select regexp_like('fooword', '^.oo'); -- 1
select regexp_like('fooword', '^f.oo'); -- 0 

select regexp_like('fooword', 'o*'); -- 1
select regexp_like('fooword', 'a*'); -- 1

select regexp_like('fooword', 'o+'); -- 1
select regexp_like('fooword', 'a+'); -- 0

select regexp_like('fooword', 'o?'); -- 1
select regexp_like('rooword', 'r?'); -- 1
select regexp_like('food', '^fo?d'); -- 0


select regexp_like('fooword', '^foo|fin$'); -- 1
select regexp_like('noword', '^foo|fin$'); -- 0
select regexp_like('foofin', '^foo|fin$'); -- 1

select regexp_like('aXbc', '[a-dXYZ]');  -- 1
select regexp_like('sXtv', '[a-dXYZ]');  -- 1
select regexp_like('sJtv', '[a-dXYZ]');  -- 0



select regexp_like('fooword', 'o{1}'); -- 1
select regexp_like('fooword', 'o{2}'); -- 1
select regexp_like('fooword', 'o{3}'); -- 0

select regexp_like('1+2', '1+2'); -- 0 busca 12 
select regexp_like('1+2', '1\+2'); -- 0 busca 1\2
select regexp_like('1+2', '1\\+2'); -- 1

select regexp_replace('fooword', 'o{2}', 'u'); -- fuword
select regexp_replace('fooword', 'o{1}','O'); -- fOOwOrd
select regexp_replace('fooXXXfin', '^foo|fin$','otro'); -- otroXXXotro


select regexp_substr('fooword', 'o{2}'); -- oo 
select regexp_substr('fooword', 'o{2}',1,1); -- oo
select regexp_substr('fooword', 'o{2}',1,2); -- null


select regexp_instr('fooword', 'o{1}'); -- 2
select regexp_instr('fooword', 'o{1}',1,2); -- 3
select regexp_instr('fooword', 'o{1}',1,3); -- 5
select regexp_instr('fooword', 'o{1}',1,4); -- 0


/*LIMPIA TELEFONO*/

select 
phone,
REGEXP_REPLACE(phone,'[^0-9]','') as limpio 
from classicmodels.customers c 


select 
phone,
REGEXP_REPLACE(
REGEXP_REPLACE(phone,'[^0-9]',''),
'^34',
'')
as limpio 
from classicmodels.customers c 
where country ='Spain'