
/* EJERCICIOS CONSULTAS RECURSIVAS */

-- Utilizar consultas recursivas para crear un calendario desde 2002 a 2025. Guardalo en una tabla llamada sandbox.TusIniciales_calendario

-- Nota, se ha modificado la configuración del servidor, cambiando
-- la variable cte_max_recursion_depth de 1000 a 10000
-- Si no habría que hacer la consulta de 1000 en 1000 registros

create table sandbox.calendario as (

with recursive cte_calendario as (
	select date('2003-01-01') as calendar_date -- fecha de inicio
	union all
	select date_add(calendar_date, interval 1 day) as calendar_date from cte_calendario 
	where year(date_add(calendar_date, interval 1 day)) <= 2025 -- condicion de fin, fecha final
)

select
calendar_date as fecha,
year(calendar_date) as fx_anno,
month(calendar_date) as fx_mes,
day(calendar_date) as fx_day,
date_format(calendar_date, '%Y%m') as fx_anno_mes,
date_format(calendar_Date,'%x-%v') as semana -- formato 
from cte_calendario

);

select * from sandbox.calendario

-- Genera la jerarquía de empleados de Classicmodels


with recursive jerarquia_empleados as
  ( select employeenumber,
           reportsto as managernumber,
           cast(null as char(50)) as managertitle,
           cast(null as char(50)) as managerofficecode,
           officecode, 
           jobTitle,
           1 nivel
   from classicmodels.employees
   where reportsto is null
     union all
     select e.employeenumber,
            e.reportsto,
            ep.jobTitle,
            ep.officecode,
            e.officecode,
            e.jobTitle,
            nivel+1
     from employees e
     inner join jerarquia_empleados ep on ep.employeenumber = e.reportsto  /* Para cada empleado busca si hay alguno del cual es su superior*/
/*No hace falta condicion de parada porque parará cuando un empleado no tenga colaboradores a su cargo*/
)
select empleados.employeenumber,
       empleados.nivel,
       empleados.jobTitle,
       oficinas.city,
       empleados.managernumber,
       empleados.managerTitle,
       oficinas_mng.city as managercity
from jerarquia_empleados empleados
inner join offices oficinas 
on empleados.officeCode=oficinas.officeCode 
left join offices oficinas_mng
on empleados.managerofficeCode=oficinas_mng.officeCode 
order by empleados.nivel, oficinas.city;

