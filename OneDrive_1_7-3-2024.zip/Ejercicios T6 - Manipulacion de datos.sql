

/* EJERCICIOS MANIPULACION DE DATOS */

-- El vicepresidente de ventas ha creado una nueva empresa. Ayúdale a montar una tabla con sus empleados

-- Crear una tabla con los empleados del mes de 2004, con los campos de la tabla employees un campo extra que sea el objetivo de ventas a conseguir (de entrada a cero)

/*
 El vicepresidente de ventas ha creado una nueva empresa. Ayúdale a montar una tabla con sus 
empleados
o Crear una tabla con los 5 empleados con más ventas de 2004, con los campos de la tabla 
employees más un campo extra que sea el objetivo de ventas a conseguir (de entrada, a cero)
o Insertar los empleados de Nueva York (si no están) en la tabla anterior e inserta al 
vicepresidente de ventas
o Modifica el superior de todos los empleados por el vicepresidente de ventas y pon de 
presidente a este
o Cambia el dominio de los emails a “modernmodels.com”
o Actualiza el objetivo de ventas, con un 20% más que lo conseguido en 2004
*/

-- Tabla intermedia con código de empleado y ventas en pedidos de 2004
-- drop table sandbox.jjpc_ejercicio_temp ;
create table sandbox.jjpc_ejercicio_temp as
(
select * from 
(
select salesRepEmployeeNumber, sum(importe_por_cliente) ventas_2004_por_empleado 
from
(
select customerNumber, sum(importe) importe_por_cliente, count(*) num_pedidos from orders pedidos
inner join
(
select orderNumber, sum(quantityOrdered*priceEach) importe 
from orderdetails o 
group by ordernumber
) detalle_pedidos
on pedidos.orderNumber = detalle_pedidos.orderNumber
where extract(year from orderDate) = 2004
group by 1
) clientes_importe
inner join customers clientes 
on clientes_importe.customerNumber = clientes.customerNumber 
group by 1
) detalle order by ventas_2024_por_empleado desc LIMIT 5
);


create table sandbox.jjpc_ejercicio as
(
select empleados.*, 0 objetivo from employees empleados 
where employeeNumber in
(
select salesRepEmployeeNumber from sandbox.jjpc_ejercicio_temp
)
);


select * from sandbox.jjpc_ejercicio 


insert into sandbox.jjpc_ejercicio 
select e.*, 0 objetivo from employees e 
-- Que sean de la oficina de Nueva York
where 
(
officeCode in 
(select officeCode from offices where city = 'NYC')
-- o que sean el Vicepresidente de Ventas
or jobTitle = 'VP Sales'
) 
-- siempre y cuando no estén ya en la tabla
and employeeNumber not in (select employeeNumber from sandbox.jjpc_ejercicio )


UPDATE sandbox.jjpc_ejercicio
set reportsTo = 1056;

UPDATE sandbox.jjpc_ejercicio
set reportsTo = null, 
jobTitle = 'President'  
where employeeNumber = 1056;

-- Comprobamos como cambiar un trozo de una cadena de texto
select 'ghernande@classicmodelcars.com', replace('ghernande@classicmodelcars.com', 'classicmodelcars.com', 'modernmodels.com')

UPDATE sandbox.jjpc_ejercicio
set email = replace(email, 'classicmodelcars.com', 'modernmodels.com');


select * from sandbox.jjpc_ejercicio_temp


UPDATE sandbox.jjpc_ejercicio tabla, sandbox.jjpc_ejercicio_temp datos
set objetivo = datos.ventas_2004_por_empleado * 1.20
where tabla.employeeNumber = datos.salesRepEmployeeNumber;

select * from sandbox.jjpc_ejercicio;

